module.exports = {
  tokens: "8283898371:AAGXiB2QJOmnHynXHXqcKtJPce0miYcofcE",
  owner: "8378254392",
  port: "2279",
  ipvps: "157.245.155.210"
};